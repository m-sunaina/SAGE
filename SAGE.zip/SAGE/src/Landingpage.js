import React from "react";
import { Link } from "react-router-dom";
import { FaUserShield, FaUser, FaLock, FaChartLine, FaShieldAlt, FaBrain, FaFingerprint, FaNetworkWired} from "react-icons/fa";
import { IoMdTime } from "react-icons/io";
import { MdSecurity, MdAccountBalance, MdSchool, MdTrendingUp, MdPeople } from "react-icons/md";

function LandingPage() {
  return (
    <div className="sage-landing">
      {/* Navigation */}
      <nav className="sage-nav">
        <div className="sage-logo">
          <FaUserShield className="sage-icon" />
          <span>SAGE</span>
        </div>
        <div className="sage-nav-links">
          <a href="#features">Features</a>
          <a href="#solutions">Solutions</a>
          <a href="#testimonials">Testimonials</a>
          <a href="#timeline">Timeline</a>
          <a href="#about">About</a>
          <a href="#contact">Contact</a>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="sage-hero">
        <div className="sage-hero-content">
          <h1>
            Secure your<br />
            digital identity with<br />
            <span className="sage-highlight">SAGE</span>
          </h1>

          <h2 className="sage-full-form">
            <span className="sage-letter">S</span>mart&nbsp;
            <span className="sage-letter">A</span>daptive&nbsp;
            <span className="sage-letter">G</span>raph-based&nbsp;
            <span className="sage-letter">E</span>valuation
          </h2>

          <p className="sage-description">
            Revolutionizing security with behavior-driven multi-factor authentication.
            Trusted by over 500 organizations worldwide.
          </p>

          <div className="sage-buttons">
            <Link to="/user-login" className="sage-btn sage-btn-user">
              <FaUser /> User Login
            </Link>
            <a href="http://localhost:5000/adminlogin" className="sage-btn sage-btn-admin">
              <FaLock /> Admin Login
            </a>
          </div>

          <a href="#learn" className="sage-learn-link">Learn how it works →</a>
        </div>

        <div className="sage-hero-image">
          <div className="sage-shield-container">
            <FaUserShield className="sage-shield-icon" />
          </div>
          <p className="sage-right-text">
            Your identity deserves smarter protection. SAGE analyzes behavior to guard access intelligently and adaptively.
          </p>
        </div>
      </section>

      {/* Stats Marquee */}
      <div className="sage-stats-marquee">
        <div className="sage-stats-track">
          <div className="sage-stat">
            <FaChartLine className="sage-stat-icon" />
            <span>98.7% Fraud Prevention</span>
          </div>
          <div className="sage-stat">
            <FaShieldAlt className="sage-stat-icon" />
            <span>500+ Organizations</span>
          </div>
          <div className="sage-stat">
            <FaBrain className="sage-stat-icon" />
            <span>AI-Powered Security</span>
          </div>
          <div className="sage-stat">
            <FaFingerprint className="sage-stat-icon" />
            <span>Zero Password Policy</span>
          </div>
          <div className="sage-stat">
            <FaNetworkWired className="sage-stat-icon" />
            <span>24/7 Protection</span>
          </div>
        </div>
      </div>

      {/* Key Features */}
      <section id="features" className="sage-section sage-features">
        <h2 className="sage-section-title">Core Features</h2>
        <div className="sage-features-grid">
          <div className="sage-feature-card">
            <MdSecurity className="sage-feature-icon" />
            <h3>Behavioral Biometrics</h3>
            <p>Analyzes typing patterns, mouse movements, and device interaction to create a unique user profile.</p>
          </div>
          <div className="sage-feature-card">
            <IoMdTime className="sage-feature-icon" />
            <h3>Continuous Authentication</h3>
            <p>Real-time monitoring ensures security isn't just at login but throughout the entire session.</p>
          </div>
          <div className="sage-feature-card">
            <FaBrain className="sage-feature-icon" />
            <h3>Adaptive Risk Scoring</h3>
            <p>Dynamically adjusts security requirements based on contextual risk factors.</p>
          </div>
          <div className="sage-feature-card">
            <FaNetworkWired className="sage-feature-icon" />
            <h3>Graph-Based Analysis</h3>
            <p>Maps user behavior patterns across multiple dimensions for comprehensive security.</p>
          </div>
        </div>
      </section>

      {/* Solutions */}
      <section id="solutions" className="sage-section sage-solutions">
        <h2 className="sage-section-title">SAGE Solutions</h2>
        <div className="sage-solutions-grid">
          <div className="sage-solution-card sage-bank">
            <MdAccountBalance className="sage-solution-icon" />
            <h3>SAGE-Bank</h3>
            <p>Secure financial transactions and prevent account takeovers with our banking-specific security layer.</p>
          </div>
          <div className="sage-solution-card sage-education">
            <MdSchool className="sage-solution-icon" />
            <h3>SAGE-Education</h3>
            <p>Protect student data and ensure secure access to educational resources and testing platforms.</p>
          </div>
          <div className="sage-solution-card sage-trade">
            <MdTrendingUp className="sage-solution-icon" />
            <h3>SAGE-Trade</h3>
            <p>Market trading security that prevents unauthorized transactions and detects insider threats.</p>
          </div>
          <div className="sage-solution-card sage-social">
            <MdPeople className="sage-solution-icon" />
            <h3>SAGE-Social</h3>
            <p>Social media protection against impersonation and unauthorized account access.</p>
          </div>
          <div className="sage-solution-card sage-network">
            <FaNetworkWired className="sage-solution-icon" />
            <h3>SAGE-Network</h3>
            <p>Comprehensive network security with behavior-based intrusion detection.</p>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="sage-section sage-testimonials">
        <h2 className="sage-section-title">Trusted By Industry Leaders</h2>
        <div className="sage-testimonial-grid">
          <div className="sage-testimonial-card">
            <div className="sage-testimonial-content">
              "Implementing SAGE reduced our security incidents by 92% while improving user experience. The adaptive authentication is revolutionary."
            </div>
            <div className="sage-testimonial-author">
              <img src="https://randomuser.me/api/portraits/women/45.jpg" alt="Sarah Johnson" />
              <div>
                <strong>Sarah Johnson</strong>
                <span>CIO, Global Bank</span>
              </div>
            </div>
          </div>
          <div className="sage-testimonial-card">
            <div className="sage-testimonial-content">
              "As an educator, I appreciate how SAGE-Education protects student data without creating login barriers. It's security that works invisibly."
            </div>
            <div className="sage-testimonial-author">
              <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="Dr. Michael Chen" />
              <div>
                <strong>Dr. Michael Chen</strong>
                <span>Dean, Tech University</span>
              </div>
            </div>
          </div>
          <div className="sage-testimonial-card">
            <div className="sage-testimonial-content">
              "Our trading platform needed ironclad security without compromising speed. SAGE-Trade delivered both exceptionally."
            </div>
            <div className="sage-testimonial-author">
              <img src="https://randomuser.me/api/portraits/women/68.jpg" alt="Emma Rodriguez" />
              <div>
                <strong>Emma Rodriguez</strong>
                <span>CEO, TradeSecure</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section id="timeline" className="sage-section sage-timeline">
        <h2 className="sage-section-title">Our Journey</h2>
        <div className="sage-timeline-container">
          <div className="sage-timeline-item">
            <div className="sage-timeline-date">Q1 2022</div>
            <div className="sage-timeline-content">
              <h3>Initial Release</h3>
              <p>Launched core behavioral authentication platform with 5 enterprise clients.</p>
            </div>
          </div>
          <div className="sage-timeline-item">
            <div className="sage-timeline-date">Q3 2022</div>
            <div className="sage-timeline-content">
              <h3>SAGE-Bank Launch</h3>
              <p>Specialized solution for financial institutions with 98.3% fraud prevention rate.</p>
            </div>
          </div>
          <div className="sage-timeline-item">
            <div className="sage-timeline-date">Q1 2023</div>
            <div className="sage-timeline-content">
              <h3>100+ Clients</h3>
              <p>Expanded to over 100 organizations across 15 countries.</p>
            </div>
          </div>
          <div className="sage-timeline-item">
            <div className="sage-timeline-date">Q3 2023</div>
            <div className="sage-timeline-content">
              <h3>Full Suite Release</h3>
              <p>Launched all specialized solutions (Education, Trade, Social, Network).</p>
            </div>
          </div>
          <div className="sage-timeline-item">
            <div className="sage-timeline-date">Q1 2024</div>
            <div className="sage-timeline-content">
              <h3>500+ Organizations</h3>
              <p>Protected over 2 million users worldwide with our technology.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="sage-section sage-cta">
        <h2>Ready to Transform Your Security?</h2>
        <p>Join thousands of organizations trusting SAGE for intelligent, adaptive protection.</p>
        <div className="sage-buttons">
          <button className="sage-btn sage-btn-primary">Request Demo</button>
          <button className="sage-btn sage-btn-secondary">Contact Sales</button>
        </div>
      </section>

      {/* Footer */}
      <footer className="sage-footer">
        <div className="sage-footer-content">
          <div className="sage-footer-logo">
            <FaUserShield className="sage-icon" />
            <span>SAGE</span>
          </div>
          <div className="sage-footer-links">
            <div className="sage-footer-column">
              <h4>Solutions</h4>
              <a href="#">SAGE-Bank</a>
              <a href="#">SAGE-Education</a>
              <a href="#">SAGE-Trade</a>
              <a href="#">SAGE-Social</a>
              <a href="#">SAGE-Network</a>
            </div>
            <div className="sage-footer-column">
              <h4>Company</h4>
              <a href="#">About Us</a>
              <a href="#">Careers</a>
              <a href="#">Newsroom</a>
              <a href="#">Partners</a>
            </div>
            <div className="sage-footer-column">
              <h4>Resources</h4>
              <a href="#">Documentation</a>
              <a href="#">API Reference</a>
              <a href="#">Blog</a>
              <a href="#">Support</a>
            </div>
          </div>
        </div>
        <div className="sage-footer-bottom">
          <p>© 2024 SAGE Security Technologies. All rights reserved.</p>
        </div>
      </footer>

      {/* Embedded CSS */}
      <style jsx>{`
        .sage-landing {
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
          color: #333;
          line-height: 1.6;
          overflow-x: hidden;
        }
        
        /* Navigation */
        .sage-nav {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 1.5rem 5%;
          background-color: #fff;
          box-shadow: 0 2px 10px rgba(0,0,0,0.1);
          position: sticky;
          top: 0;
          z-index: 100;
        }
        
        .sage-logo {
          display: flex;
          align-items: center;
          font-size: 1.8rem;
          font-weight: 700;
          color: #2c3e50;
        }
        
        .sage-icon {
          margin-right: 0.5rem;
          color: #3498db;
          font-size: 2rem;
        }
        
        .sage-nav-links {
          display: flex;
          gap: 2rem;
        }
        
        .sage-nav-links a {
          text-decoration: none;
          color: #2c3e50;
          font-weight: 500;
          transition: color 0.3s;
        }
        
        .sage-nav-links a:hover {
          color: #3498db;
        }
        
        /* Hero Section */
        .sage-hero {
          display: flex;
          padding: 5% 5%;
          background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
          min-height: 80vh;
          align-items: center;
        }
        
        .sage-hero-content {
          flex: 1;
          padding-right: 5%;
        }
        
        .sage-hero-image {
          flex: 1;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
        }
        
        .sage-hero h1 {
          font-size: 3.5rem;
          font-weight: 800;
          margin-bottom: 1.5rem;
          line-height: 1.2;
          color: #2c3e50;
        }
        
        .sage-highlight {
          color: #3498db;
        }
        
        .sage-full-form {
          font-size: 1.5rem;
          margin-bottom: 1.5rem;
          color: #7f8c8d;
          font-weight: 600;
        }
        
        .sage-letter {
          color: #3498db;
          font-size: 1.8rem;
        }
        
        .sage-description {
          font-size: 1.2rem;
          margin-bottom: 2rem;
          color: #34495e;
          max-width: 80%;
        }
        
        .sage-buttons {
          display: flex;
          gap: 1rem;
          margin-bottom: 2rem;
        }
        
        .sage-btn {
          padding: 0.8rem 1.5rem;
          border-radius: 50px;
          text-decoration: none;
          font-weight: 600;
          display: inline-flex;
          align-items: center;
          gap: 0.5rem;
          transition: all 0.3s;
        }
        
        .sage-btn-user {
          background-color: #3498db;
          color: white;
          border: 2px solid #3498db;
        }
        
        .sage-btn-admin {
          background-color: transparent;
          color: #3498db;
          border: 2px solid #3498db;
        }
        
        .sage-btn-user:hover {
          background-color: #2980b9;
          border-color: #2980b9;
          transform: translateY(-2px);
        }
        
        .sage-btn-admin:hover {
          background-color: rgba(52, 152, 219, 0.1);
          transform: translateY(-2px);
        }
        
        .sage-learn-link {
          color: #3498db;
          text-decoration: none;
          font-weight: 600;
          display: inline-block;
          transition: transform 0.3s;
        }
        
        .sage-learn-link:hover {
          transform: translateX(5px);
        }
        
        .sage-shield-container {
          background-color: white;
          width: 200px;
          height: 200px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 10px 30px rgba(0,0,0,0.1);
          margin-bottom: 2rem;
        }
        
        .sage-shield-icon {
          font-size: 5rem;
          color: #3498db;
        }
        
        .sage-right-text {
          font-size: 1.1rem;
          color: #34495e;
          max-width: 80%;
          text-align: center;
        }
        
        /* Stats Marquee */
        .sage-stats-marquee {
          background-color: #2c3e50;
          color: white;
          padding: 1.5rem 0;
          overflow: hidden;
        }
        
        .sage-stats-track {
          display: flex;
          gap: 3rem;
          animation: scroll 20s linear infinite;
          width: max-content;
        }
        
        @keyframes scroll {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        
        .sage-stat {
          display: flex;
          align-items: center;
          gap: 0.8rem;
          white-space: nowrap;
        }
        
        .sage-stat-icon {
          font-size: 1.5rem;
          color: #3498db;
        }
        
        /* Sections */
        .sage-section {
          padding: 5rem 5%;
        }
        
        .sage-section-title {
          text-align: center;
          font-size: 2.5rem;
          margin-bottom: 3rem;
          color: #2c3e50;
          position: relative;
        }
        
        .sage-section-title::after {
          content: '';
          display: block;
          width: 80px;
          height: 4px;
          background-color: #3498db;
          margin: 1rem auto 0;
        }
        
        /* Features */
        .sage-features-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 2rem;
        }
        
        .sage-feature-card {
          background-color: white;
          border-radius: 10px;
          padding: 2rem;
          box-shadow: 0 5px 15px rgba(0,0,0,0.05);
          transition: transform 0.3s, box-shadow 0.3s;
          text-align: center;
        }
        
        .sage-feature-card:hover {
          transform: translateY(-10px);
          box-shadow: 0 15px 30px rgba(0,0,0,0.1);
        }
        
        .sage-feature-icon {
          font-size: 2.5rem;
          color: #3498db;
          margin-bottom: 1.5rem;
        }
        
        .sage-feature-card h3 {
          font-size: 1.5rem;
          margin-bottom: 1rem;
          color: #2c3e50;
        }
        
        .sage-feature-card p {
          color: #7f8c8d;
        }
        
        /* Solutions */
        .sage-solutions {
          background-color: #f8f9fa;
        }
        
        .sage-solutions-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 2rem;
        }
        
        .sage-solution-card {
          background-color: white;
          border-radius: 10px;
          padding: 2rem;
          box-shadow: 0 5px 15px rgba(0,0,0,0.05);
          transition: all 0.3s;
          border-top: 4px solid transparent;
        }
        
        .sage-solution-card:hover {
          transform: translateY(-5px);
          box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        
        .sage-solution-icon {
          font-size: 2rem;
          margin-bottom: 1rem;
        }
        
        .sage-bank {
          border-top-color: #3498db;
        }
        
        .sage-education {
          border-top-color: #e74c3c;
        }
        
        .sage-trade {
          border-top-color: #2ecc71;
        }
        
        .sage-social {
          border-top-color: #9b59b6;
        }
        
        .sage-network {
          border-top-color: #f39c12;
        }
        
        .sage-solution-card h3 {
          font-size: 1.5rem;
          margin-bottom: 1rem;
          color: #2c3e50;
        }
        
        .sage-solution-card p {
          color: #7f8c8d;
        }
        
        /* Testimonials */
        .sage-testimonials {
          background-color: #2c3e50;
          color: white;
        }
        
        .sage-testimonials .sage-section-title {
          color: white;
        }
        
        .sage-testimonials .sage-section-title::after {
          background-color: #3498db;
        }
        
        .sage-testimonial-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 2rem;
        }
        
        .sage-testimonial-card {
          background-color: rgba(255,255,255,0.1);
          border-radius: 10px;
          padding: 2rem;
          transition: transform 0.3s;
        }
        
        .sage-testimonial-card:hover {
          transform: translateY(-5px);
        }
        
        .sage-testimonial-content {
          font-style: italic;
          margin-bottom: 1.5rem;
          position: relative;
        }
        
        .sage-testimonial-content::before {
          content: '"';
          font-size: 4rem;
          position: absolute;
          top: -1.5rem;
          left: -1rem;
          opacity: 0.2;
        }
        
        .sage-testimonial-author {
          display: flex;
          align-items: center;
          gap: 1rem;
        }
        
        .sage-testimonial-author img {
          width: 50px;
          height: 50px;
          border-radius: 50%;
          object-fit: cover;
        }
        
        .sage-testimonial-author div {
          display: flex;
          flex-direction: column;
        }
        
        .sage-testimonial-author strong {
          font-weight: 600;
        }
        
        .sage-testimonial-author span {
          opacity: 0.8;
          font-size: 0.9rem;
        }
        
        /* Timeline */
        .sage-timeline-container {
          position: relative;
          max-width: 800px;
          margin: 0 auto;
          padding-left: 50px;
        }
        
        .sage-timeline-container::before {
          content: '';
          position: absolute;
          left: 20px;
          top: 0;
          bottom: 0;
          width: 2px;
          background-color: #3498db;
        }
        
        .sage-timeline-item {
          position: relative;
          margin-bottom: 3rem;
        }
        
        .sage-timeline-item::before {
          content: '';
          position: absolute;
          left: -40px;
          top: 5px;
          width: 20px;
          height: 20px;
          border-radius: 50%;
          background-color: #3498db;
          border: 3px solid white;
          box-shadow: 0 0 0 3px #3498db;
        }
        
        .sage-timeline-date {
          font-weight: 600;
          color: #3498db;
          margin-bottom: 0.5rem;
        }
        
        .sage-timeline-content {
          background-color: white;
          border-radius: 10px;
          padding: 1.5rem;
          box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
        
        .sage-timeline-content h3 {
          margin-top: 0;
          color: #2c3e50;
        }
        
        .sage-timeline-content p {
          color: #7f8c8d;
          margin-bottom: 0;
        }
        
        /* CTA */
        .sage-cta {
          text-align: center;
          background: linear-gradient(135deg, #3498db 0%, #2c3e50 100%);
          color: white;
          padding: 4rem 5%;
        }
        
        .sage-cta h2 {
          font-size: 2.5rem;
          margin-bottom: 1rem;
        }
        
        .sage-cta p {
          font-size: 1.2rem;
          max-width: 700px;
          margin: 0 auto 2rem;
        }
        
        .sage-btn-primary {
          background-color: white;
          color: #3498db;
          border: 2px solid white;
        }
        
        .sage-btn-secondary {
          background-color: transparent;
          color: white;
          border: 2px solid white;
        }
        
        .sage-btn-primary:hover {
          background-color: rgba(255,255,255,0.9);
          transform: translateY(-2px);
        }
        
        .sage-btn-secondary:hover {
          background-color: rgba(255,255,255,0.1);
          transform: translateY(-2px);
        }
        
        /* Footer */
        .sage-footer {
          background-color: #2c3e50;
          color: white;
          padding: 3rem 5% 1rem;
        }
        
        .sage-footer-content {
          display: flex;
          flex-wrap: wrap;
          gap: 3rem;
          margin-bottom: 2rem;
        }
        
        .sage-footer-logo {
          display: flex;
          align-items: center;
          font-size: 1.8rem;
          font-weight: 700;
          margin-bottom: 1rem;
        }
        
        .sage-footer-links {
          display: flex;
          flex-wrap: wrap;
          gap: 3rem;
          flex: 1;
          justify-content: space-between;
        }
        
        .sage-footer-column {
          min-width: 150px;
        }
        
        .sage-footer-column h4 {
          margin-bottom: 1.5rem;
          font-size: 1.2rem;
        }
        
        .sage-footer-column a {
          display: block;
          color: #bdc3c7;
          text-decoration: none;
          margin-bottom: 0.8rem;
          transition: color 0.3s;
        }
        
        .sage-footer-column a:hover {
          color: #3498db;
        }
        
        .sage-footer-bottom {
          text-align: center;
          padding-top: 2rem;
          border-top: 1px solid rgba(255,255,255,0.1);
          color: #bdc3c7;
          font-size: 0.9rem;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
          .sage-hero {
            flex-direction: column;
            text-align: center;
          }
          
          .sage-hero-content {
            padding-right: 0;
            margin-bottom: 3rem;
          }
          
          .sage-description {
            max-width: 100%;
          }
          
          .sage-buttons {
            justify-content: center;
          }
          
          .sage-nav-links {
            display: none;
          }
        }
      `}</style>
    </div>
  );
}

export default LandingPage;