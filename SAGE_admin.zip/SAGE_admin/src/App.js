// App.js
import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
} from 'react-router-dom';
import LandingPage from "./components/Landingpage";
import UserLogin from "./components/Userlogin";
import AdminLogin from "./components/adminlogin";
import AdminDashboard from "./components/admindashboard";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/user-login" element={<UserLogin />} />
        <Route path="/AdminLogin" element={<AdminLogin/>} />
        <Route path="/admindashboard" element={<AdminDashboard />} />
      </Routes>
    </Router>
  );
}

export default App;
