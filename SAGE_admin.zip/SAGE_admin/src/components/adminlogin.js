import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/adminlogin.css';

export default function AdminLogin() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    if (email === 'admin@example.com' && password === 'admin123') {
      // Optionally store admin session
      localStorage.setItem('admin-auth', 'true');
      setError('');
      navigate('/admindashboard');
    } else {
      setError('Invalid email or password');
    }
  };

  return (
    <form className="login-box" onSubmit={handleSubmit}>
      <h2 className="login-title">Admin Login</h2>
      {error && <p className="error-msg">{error}</p>}
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={e => setEmail(e.target.value)}
        required
        className="input-field"
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={e => setPassword(e.target.value)}
        required
        className="input-field"
      />
      <button type="submit" className="login-button">
        Login
      </button>
    </form>
  );
}
