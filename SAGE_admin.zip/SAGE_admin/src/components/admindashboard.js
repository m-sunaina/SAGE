import React, { useState, useEffect, useRef } from 'react';
import '../styles/admindashboard.css';
import {
    FaTachometerAlt,
    FaUsers,
    FaChartLine,
    FaBell,
    FaGraduationCap,
    FaJournalWhills,
    FaCog,
    FaSun,
    FaMoon,
    FaBars,
    FaChevronLeft,
    FaUserCircle,
    FaSignOutAlt,
} from 'react-icons/fa';

function App() {
    const [activeTab, setActiveTab] = useState('dashboard');
    const [darkMode, setDarkMode] = useState(false);
    const [sidebarOpen, setSidebarOpen] = useState(true);
    const [chatbotOpen, setChatbotOpen] = useState(false);
    const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
    const userMenuRef = useRef(null);

    // Mock data
    const users = [
        { id: 1, name: 'John Doe', email: 'john@example.com', status: 'active', lastActive: '2023-05-15T10:30:00' },
        { id: 2, name: 'Jane Smith', email: 'jane@example.com', status: 'inactive', lastActive: '2023-05-10T14:45:00' },
        { id: 3, name: 'Bob Johnson', email: 'bob@example.com', status: 'active', lastActive: '2023-05-16T08:15:00' },
    ];

    const alerts = [
        { id: 1, type: 'warning', message: 'Server load high', timestamp: '2023-05-16T09:30:00' },
        { id: 2, type: 'error', message: 'Database connection failed', timestamp: '2023-05-16T10:15:00', resolved: false },
        { id: 3, type: 'info', message: 'New user registered', timestamp: '2023-05-16T11:45:00' },
    ];

    const adminActions = [
        { id: 1, action: 'User created', admin: 'Admin', timestamp: '2023-05-16T08:30:00' },
        { id: 2, action: 'Settings updated', admin: 'Admin', timestamp: '2023-05-16T09:15:00' },
        { id: 3, action: 'Alert resolved', admin: 'Admin', timestamp: '2023-05-16T10:30:00' },
    ];

    const [chatMessages, setChatMessages] = useState([
    { 
        id: 1, 
        sender: 'bot', 
        message: 'Hello! I am your AI assistant powered by Llama 3. How can I help you today?', 
        timestamp: new Date() 
    }
]);

    const activeUsers = users.filter(user => user.status === 'active').length;

    // Close user menu when clicking outside
    useEffect(() => {
        const handleClickOutside = (event) => {
            if (userMenuRef.current && !userMenuRef.current.contains(event.target)) {
                setIsUserMenuOpen(false);
            }
        };

        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    const toggleDarkMode = () => setDarkMode(!darkMode);
    const toggleSidebar = () => setSidebarOpen(!sidebarOpen);
    const toggleChatbot = () => setChatbotOpen(!chatbotOpen);
    const toggleUserMenu = () => setIsUserMenuOpen(!isUserMenuOpen);

    const handleLogout = () => {
        console.log('User logged out');
        setIsUserMenuOpen(false);
    };

    const handleProfile = () => {
        console.log('Viewing profile');
        setIsUserMenuOpen(false);
    };

    const callOllama = async (message, model = 'llama3.2') => {
    try {
        const response = await fetch('http://localhost:11434/api/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                model,
                messages: [{ role: 'user', content: message }],
                stream: false
            })
        });

        if (!response.ok) {
            throw new Error(`Ollama API error: ${response.status}`);
        }

        const data = await response.json();
        return data.message.content;
    } catch (error) {
        console.error('Error calling Ollama:', error);
        return "Sorry, I'm having trouble connecting to the AI service.";
    }
};

    const handleSendMessage = async (message) => {
    const newMessage = {
        id: chatMessages.length + 1,
        sender: 'user',
        message,
        timestamp: new Date()
    };

    setChatMessages(prev => [...prev, newMessage]);

    try {
        const botResponse = await callOllama(message);
        const botMessage = {
            id: chatMessages.length + 2,
            sender: 'bot',
            message: botResponse,
            timestamp: new Date()
        };
        setChatMessages(prev => [...prev, botMessage]);
    } catch (error) {
        console.error('Error getting bot response:', error);
        const errorMessage = {
            id: chatMessages.length + 2,
            sender: 'bot',
            message: "Sorry, I encountered an error. Please try again later.",
            timestamp: new Date()
        };
        setChatMessages(prev => [...prev, errorMessage]);
    }
};

    return (
        <div className={`app ${darkMode ? 'dark' : 'light'}`}>
            {/* Sidebar */}
            <div className={`sidebar ${sidebarOpen ? 'open' : 'closed'}`}>
                <div className="sidebar-header">
                    {sidebarOpen ? (
                        <>
                            <h2>Admin Panel</h2>
                            <button className="sidebar-toggle" onClick={toggleSidebar} title="Collapse sidebar">
                                <FaChevronLeft />
                            </button>
                        </>
                    ) : (
                        <button className="sidebar-toggle" onClick={toggleSidebar} title="Expand sidebar">
                            <FaBars />
                        </button>
                    )}
                </div>
                <nav>
                    <ul>
                        <li
                            className={activeTab === 'dashboard' ? 'active' : ''}
                            onClick={() => setActiveTab('dashboard')}
                            title={!sidebarOpen ? 'Dashboard' : ''}
                        >
                            <FaTachometerAlt className="icon" />
                            {sidebarOpen && <span>Dashboard</span>}
                        </li>
                        <li
                            className={activeTab === 'users' ? 'active' : ''}
                            onClick={() => setActiveTab('users')}
                            title={!sidebarOpen ? 'Users' : ''}
                        >
                            <FaUsers className="icon" />
                            {sidebarOpen && <span>Users</span>}
                        </li>
                        <li
                            className={activeTab === 'activity' ? 'active' : ''}
                            onClick={() => setActiveTab('activity')}
                            title={!sidebarOpen ? 'Activity' : ''}
                        >
                            <FaChartLine className="icon" />
                            {sidebarOpen && <span>Activity</span>}
                        </li>
                        <li
                            className={activeTab === 'alerts' ? 'active' : ''}
                            onClick={() => setActiveTab('alerts')}
                            title={!sidebarOpen ? 'Alerts' : ''}
                        >
                            <FaBell className="icon" />
                            {sidebarOpen && <span>Alerts</span>}
                        </li>
                       <li
    className={activeTab === 'reports' ? 'active' : ''}
    title={!sidebarOpen ? 'Reports' : ''}
>
    <a 
        href="http://127.0.0.1:5500/report-summ.html" 
        target="_blank" 
        rel="noopener noreferrer"
        style={{ 
            display: 'flex', 
            alignItems: 'center', 
            textDecoration: 'none', 
            color: 'inherit',
            padding: '10px 15px',
            width: '100%'
        }}
    >
        <FaJournalWhills className="icon" />
        {sidebarOpen && <span>Reports</span>}
    </a>
</li>

<li
    className={activeTab === 'edumonitor' ? 'active' : ''}
    title={!sidebarOpen ? 'Edu Monitor' : ''}
>
    <a 
        href="http://localhost:5177/" 
        target="_blank" 
        rel="noopener noreferrer"
        style={{ 
            display: 'flex', 
            alignItems: 'center', 
            textDecoration: 'none', 
            color: 'inherit',
            padding: '10px 15px',
            width: '100%'
        }}
    >
        <FaGraduationCap className="icon" />
        {sidebarOpen && <span>Edu Monitor</span>}
    </a>
</li>
                        <li
                            className={activeTab === 'settings' ? 'active' : ''}
                            onClick={() => setActiveTab('settings')}
                            title={!sidebarOpen ? 'Settings' : ''}
                        >
                            <FaCog className="icon" />
                            {sidebarOpen && <span>Settings</span>}
                        </li>
                    </ul>
                </nav>
                <div className="sidebar-footer">
                    <button onClick={toggleDarkMode} title={!sidebarOpen ? (darkMode ? 'Light Mode' : 'Dark Mode') : ''}>
                        {darkMode ? <FaSun className="icon" /> : <FaMoon className="icon" />}
                        {sidebarOpen && (darkMode ? 'Light Mode' : 'Dark Mode')}
                    </button>
                </div>
            </div>

            {/* Main Content */}
            <div className="main-content">
                <header className="top-bar">
                    <div className="search-bar">
                        <input type="text" placeholder="Search..." />
                    </div>
                    <div className="user-info" ref={userMenuRef}>
                        <div className="user-display" onClick={toggleUserMenu}>
                            <span>Welcome, Admin</span>
                            <div className="user-avatar">A</div>
                        </div>
                        {isUserMenuOpen && (
                            <div className="user-dropdown">
                                <div className="dropdown-item" onClick={handleProfile}>
                                    <FaUserCircle className="dropdown-icon" />
                                    <span>Profile</span>
                                </div>
                                <div className="dropdown-item" onClick={handleLogout}>
                                    <FaSignOutAlt className="dropdown-icon" />
                                    <span>Logout</span>
                                </div>
                                <div className="dropdown-item">
                                    <FaCog className="dropdown-icon" />
                                    <span>Settings</span>
                                </div>
                            </div>
                        )}
                    </div>
                </header>

                <div className="content-container">
                    {activeTab === 'dashboard' && (
                        <DashboardView
                            activeUsers={activeUsers}
                            totalUsers={users.length}
                            recentAlerts={alerts.slice(0, 3)}
                            recentActions={adminActions.slice(0, 3)}
                        />
                    )}

                    {activeTab === 'users' && <UsersView users={users} />}

                    {activeTab === 'activity' && <ActivityView actions={adminActions} />}

                    {activeTab === 'alerts' && <AlertsView alerts={alerts} />}

                    {activeTab === 'settings' && <SettingsView />}
                </div>
            </div>

            {/* Chatbot */}
            <button className="chatbot-button" onClick={toggleChatbot}>
                <i className="icon-chat"></i>
            </button>

            {chatbotOpen && (
                <Chatbot
                    messages={chatMessages}
                    onSend={handleSendMessage}
                    onClose={toggleChatbot}
                />
            )}
        </div>
    );
}

// Dashboard View Component
function DashboardView({ activeUsers, totalUsers, recentAlerts, recentActions }) {
    return (
        <div className="view-content">
            <h1>Dashboard Overview</h1>

            <div className="stats-cards">
                <div className="stat-card">
                    <h3>Active Users</h3>
                    <p>{activeUsers}</p>
                </div>
                <div className="stat-card">
                    <h3>Total Users</h3>
                    <p>{totalUsers}</p>
                </div>
                <div className="stat-card">
                    <h3>Unresolved Alerts</h3>
                    <p>{recentAlerts.filter(a => !a.resolved).length}</p>
                </div>
            </div>

            <div className="dashboard-grid">
                <div className="recent-alerts">
                    <h2>Recent Alerts</h2>
                    <ul>
                        {recentAlerts.map(alert => (
                            <li key={alert.id} className={alert.type}>
                                <span className="alert-message">{alert.message}</span>
                                <span className="alert-time">
                                    {new Date(alert.timestamp).toLocaleString()}
                                </span>
                            </li>
                        ))}
                    </ul>
                </div>

                <div className="recent-actions">
                    <h2>Recent Admin Actions</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>Action</th>
                                <th>Admin</th>
                                <th>Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            {recentActions.map(action => (
                                <tr key={action.id}>
                                    <td>{action.action}</td>
                                    <td>{action.admin}</td>
                                    <td>{new Date(action.timestamp).toLocaleString()}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}

// Users View Component
function UsersView({ users }) {
    return (
        <div className="view-content">
            <h1>User Management</h1>

            <div className="view-actions">
                <button>Add User</button>
                <button>Export Data</button>
                <input type="text" placeholder="Filter users..." />
            </div>

            <div className="table-container">
                <table className="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Last Active</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {users.map(user => (
                            <tr key={user.id}>
                                <td>{user.id}</td>
                                <td>{user.name}</td>
                                <td>{user.email}</td>
                                <td>
                                    <span className={`status-badge ${user.status}`}>
                                        {user.status}
                                    </span>
                                </td>
                                <td>{new Date(user.lastActive).toLocaleString()}</td>
                                <td>
                                    <button className="action-edit">Edit</button>
                                    <button className="action-delete">Delete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

// Activity View Component
function ActivityView({ actions }) {
    return (
        <div className="view-content">
            <h1>Admin Activity Log</h1>

            <div className="view-actions">
                <select>
                    <option>All Actions</option>
                    <option>User Management</option>
                    <option>Settings Changes</option>
                    <option>Alert Resolutions</option>
                </select>
                <input type="date" />
                <input type="date" />
                <button>Apply Filters</button>
            </div>

            <div className="table-container">
                <table className="data-table">
                    <thead>
                        <tr>
                            <th>Admin</th>
                            <th>Action</th>
                            <th>Timestamp</th>
                        </tr>
                    </thead>
                    <tbody>
                        {actions.map(action => (
                            <tr key={action.id}>
                                <td>{action.admin}</td>
                                <td>{action.action}</td>
                                <td>{new Date(action.timestamp).toLocaleString()}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

// Alerts View Component
function AlertsView({ alerts }) {
    return (
        <div className="view-content">
            <h1>System Alerts</h1>

            <div className="view-actions">
                <select>
                    <option>All Alerts</option>
                    <option>Unresolved Only</option>
                    <option>Errors</option>
                    <option>Warnings</option>
                    <option>Info</option>
                </select>
                <button>Clear Filters</button>
            </div>

            <div className="table-container">
                <table className="data-table">
                    <thead>
                        <tr>
                            <th>Type</th>
                            <th>Message</th>
                            <th>Timestamp</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {alerts.map(alert => (
                            <tr key={alert.id} className={alert.type}>
                                <td>{alert.type}</td>
                                <td>{alert.message}</td>
                                <td>{new Date(alert.timestamp).toLocaleString()}</td>
                                <td>
                                    {alert.resolved ? 'Resolved' : 'Unresolved'}
                                </td>
                                <td>
                                    {!alert.resolved && (
                                        <button className="action-resolve">
                                            Mark Resolved
                                        </button>
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

// Settings View Component
function SettingsView() {
    const [settings, setSettings] = useState({
        notifications: true,
        emailReports: false,
        autoRefresh: true,
        dataRetention: '30 days'
    });

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setSettings(prev => ({
            ...prev,
            [name]: type === 'checkbox' ? checked : value
        }));
    };

    return (
        <div className="view-content">
            <h1>System Settings</h1>

            <form className="settings-form">
                <div className="setting-group">
                    <h2>Notification Settings</h2>

                    <label>
                        <input
                            type="checkbox"
                            name="notifications"
                            checked={settings.notifications}
                            onChange={handleChange}
                        />
                        Enable Notifications
                    </label>

                    <label>
                        <input
                            type="checkbox"
                            name="emailReports"
                            checked={settings.emailReports}
                            onChange={handleChange}
                        />
                        Email Weekly Reports
                    </label>
                </div>

                <div className="setting-group">
                    <h2>Performance Settings</h2>

                    <label>
                        <input
                            type="checkbox"
                            name="autoRefresh"
                            checked={settings.autoRefresh}
                            onChange={handleChange}
                        />
                        Auto-refresh Dashboard
                    </label>
                </div>

                <div className="setting-group">
                    <h2>Data Settings</h2>

                    <label>
                        Data Retention Period:
                        <select
                            name="dataRetention"
                            value={settings.dataRetention}
                            onChange={handleChange}
                        >
                            <option>7 days</option>
                            <option>30 days</option>
                            <option>90 days</option>
                            <option>1 year</option>
                            <option>Indefinite</option>
                        </select>
                    </label>
                </div>

                <button type="button" className="save-settings">
                    Save Settings
                </button>
            </form>
        </div>
    );
}

// Chatbot Component
function Chatbot({ messages, onSend, onClose }) {
    const [message, setMessage] = useState('');

    const handleSend = () => {
        if (message.trim()) {
            onSend(message.trim());
            setMessage('');
        }
    };

    return (
        <div className="chatbot-panel">
            <div className="chatbot-header">
                <h3>Support Chat</h3>
                <button onClick={onClose}>×</button>
            </div>
            <div className="chat-messages">
                {messages.map(msg => (
                    <div key={msg.id} className={`message ${msg.sender}`}>
                        <p>{msg.message}</p>
                        <span className="timestamp">
                            {new Date(msg.timestamp).toLocaleTimeString()}
                        </span>
                    </div>
                ))}
            </div>
            <div className="chat-input">
                <input
                    type="text"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Type your message..."
                    onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                />
                <button onClick={handleSend}>Send</button>
            </div>
        </div>
    );
}

export default App;